#!/bin/bash
#
#
echo "this is a patchstick stript"
#
#
#
